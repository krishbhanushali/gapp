/*package gapp.model.dao;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTransactionalTestNGSpringContextTests;
import org.testng.annotations.Test;

import gapp.model.Applications;
import gapp.model.Students;
import gapp.model.User;
import gapp.model.dao.ApplicationsDao;
import gapp.model.dao.StudentDao;
import gapp.model.dao.UserDao;



@Test(groups = "StudentDaoTest")
@ContextConfiguration(locations = "classpath:applicationContext.xml")
public class StudentDaoTest extends AbstractTransactionalTestNGSpringContextTests {

    @Autowired
    ApplicationsDao applicationsDao;
    
    @Autowired
    UserDao userDao;
    
    @Autowired
    StudentDao studentDao;
    
    int count=0;
    @Test
    public void checkStudent(){
    	User user = userDao.getUser("student1");
    	Students student = studentDao.getStudent(user);
    	List<Applications> application = applicationsDao.getApplication(student);
    	assert application.size()==1;
    }
    
    
}*/