package gapp.model.dao;

import java.util.List;

import gapp.model.Terms;
public interface TermsDao {
	Terms getTerm(Integer id);
	Terms getTerm(String termName);
	List<Terms> getAllTerms();
}
