package gapp.model.dao;

import gapp.model.Role;

public interface RoleDao {
	Role getRole(Integer id);
}
