drop table academic_records;
drop table additional_fields;
drop table additional_fields_departments;
drop table additional_field_values;
drop table application_status;
drop table departments;
drop table education_college;
drop table programs;
drop table students;
drop table terms;
drop table user_role;
drop table users;

drop sequence hibernate_sequence;